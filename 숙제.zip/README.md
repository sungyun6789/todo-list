1. TodoList - React, React-Hooks, styled-component 사용

2. styled-component를 활용해 component에는 js부분만 보일 수 있도록 해서 가독성을 올렸다.

3. styledcomponent 파일을 따로 만들어 디자인 부분을 따로 분리해놨다.

4. 코드 옆에 주석을 사용해 하나하나 해석하는 작업을 했다.

5. 해석 덕분에 모르는 사람이 봐도 이 코드가 어떻게 작동하는지 알 수 있도록 작업했다.